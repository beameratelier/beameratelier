# Snowdrop User Guide (Manual)

## 1. Overview
Snowdrop is a structured Beamer theme designed for clarity, stability, and controlled visual hierarchy. It provides:
- Custom title slide
- Dedicated outline slide
- Automatic section pages
- Dual-layer headline navigation with progress bar
- Closing “Thank you” slide
- References environment with automatic frame breaks

## 2. Title Slide
Use:
```latex
\maketitle
```
Snowdrop renders a plain (non-numbered) title frame showing title, subtitle, author, institute, and date.

## 3. Outline Slide
Use:
```latex
\makeoutline
```
Snowdrop renders a plain (non-numbered) outline frame. The table of contents is formatted for stability.
Long section/subsection entries are truncated by design to preserve layout integrity.

## 4. Section Pages (Automatic)
Snowdrop inserts a dedicated section page at the start of each section via:
```latex
\AtBeginSection{\SnowdropSectionPage}
```
Section titles are truncated to avoid overflow. The slide includes a progress bar.

## 5. Headline Navigation
Snowdrop uses a two-row headline:
1) A top navigation row listing sections.
2) A second row with the current section, optional subsection indicator, and a progress bar.

Long titles are truncated for stability.

## 6. Thank You Slide
Use:
```latex
\makethankyou
```
Creates a closing slide (plain, non-numbered).

## 7. References
Use the Snowdrop references environment:
```latex
\begin{SnowdropReferences}[References]
  \bibliography{yourbibfile}
\end{SnowdropReferences}
```
This creates a plain, non-numbered references section with automatic frame breaks.

Recommended bib setup:
```latex
\usepackage[authoryear]{natbib}
\bibliographystyle{apalike}
```

## 8. Customisation
Primary colour is set by:
```latex
\SnowdropSetMainColor{4a4e69}
```
Use any 6-digit hex value (without #).

## 9. Support
Contact: hellobeameratelier@gmail.com
Include your LaTeX distribution and a minimal example when requesting help.

## Load the theme

1. Put the theme file in the same folder as your `.tex` file.
2. In your preamble, add:

```latex
\usetheme{snowdrop}
```
