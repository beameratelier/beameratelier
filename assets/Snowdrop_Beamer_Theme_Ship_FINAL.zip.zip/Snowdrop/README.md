# Snowdrop — Beamer Theme
By Beamer Atelier

Snowdrop is a refined LaTeX Beamer theme designed for academic and professional presentations. It emphasizes visual restraint, structural clarity, and layout stability.

## Quick Start
## Load the theme

1. Put the theme file in the same folder as your `.tex` file.
2. In your preamble, add:

```latex
\usetheme{snowdrop}
```


```latex
\documentclass[aspectratio=169,11pt]{beamer}
% Load Snowdrop theme
\usetheme{snowdrop}

\title{Presentation Title}
\subtitle{Optional Subtitle}
\author{Your Name}
\institute{Your Institution}
\date{\today}

\begin{document}

\maketitle
\makeoutline

\section{Section Title}
\begin{frame}{Frame Title}
Content here.
\end{frame}

\makethankyou

\end{document}
```

## Included Commands

- `\maketitle` → Snowdrop title slide
- `\makeoutline` → Snowdrop outline slide
- `\makethankyou` → Snowdrop closing slide
- `SnowdropReferences` environment → references slides (frame breaks supported)

## Requirements

- LaTeX distribution: TeX Live / MiKTeX (recent)
- `beamer` class
- Packages: `tikz`, `xstring`, `etoolbox`, `xcolor`
- Fonts: Fira Sans + Fira Mono
- `natbib` (if using the references environment)

For full documentation, see `USER_GUIDE.md`.
License terms: `LICENSE.txt`.
Refund policy: `REFUND_POLICY.txt`.

## Support

For licensing or support, contact: **hellobeameratelier@gmail.com**
