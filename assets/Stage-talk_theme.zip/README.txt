Stage-talk
==========

Stage-talk is a LaTeX theme built on top of the ltx-talk framework.
It provides structured tagging capabilities for tables and images,
ensuring semantic PDF output and accessibility-ready academic documents.

This package is distributed directly via our website (not via CTAN).

------------------------------------------------------------
INSTALLATION
------------------------------------------------------------

1. Extract the zip file.
2. Place the following files in your working directory:
   - ltxtalk.cls
   - Stage-talk.sty
   - Supporting documentation files
3. Compile your document using:

   \DocumentMetadata{tagging=on, lang=en-GB}
   \documentclass{ltxtalk}
   \usepackage{Stage-talk}

------------------------------------------------------------
BASIC STRUCTURE (main.tex)
------------------------------------------------------------

\title{Your Title}
\author{Your Name}

\begin{document}
\maketitle

\begin{frame}{Outline}
\tableofcontents
\end{frame}

\section{Section Title}

\begin{frame}{Frame Title}
Content here
\end{frame}

\end{document}

------------------------------------------------------------
TAGGED TABLES
------------------------------------------------------------

\begin{Table}
  \begin{THead}
    \begin{TR}
      \TH{Header 1}
      \TH{Header 2}
    \end{TR}
  \end{THead}
  \begin{TBody}
    \begin{TR}
      \TD{Value 1}
      \TD{Value 2}
    \end{TR}
  \end{TBody}
\end{Table}

------------------------------------------------------------
TAGGED IMAGES
------------------------------------------------------------

\includegraphics[width=0.8\linewidth, alt={Description of image}]{image.png}

------------------------------------------------------------
VERSION
------------------------------------------------------------

Current Version: 1.0

For updates and documentation, visit our official website.
